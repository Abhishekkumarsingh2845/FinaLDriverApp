import React, { useState } from "react";
import { View, Button, TextInput, FlatList, Text } from "react-native";

const MyComponent = () => {
  const [data, setData] = useState([]);

  const addData = (newText) => {
    setData((prev) => [...prev, newText]);
  };

  return (
    <View>
      <TextInput
        placeholder="Enter text"
        onSubmitEditing={(e) => addData(e.nativeEvent.text)}
      />
      <FlatList
        data={data}
        renderItem={({ item }) => <Text>{item}</Text>}
        keyExtractor={(item, index) => index.toString()}
      />
    </View>
  );
};

export default MyComponent;
